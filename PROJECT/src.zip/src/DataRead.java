

public class DataRead {
	
	public static void readData(String fileName, int bufferSize) {
		
	}

}
