
public class DataSort {
	
	public static void mergeSort(int[] dataArray, int low, int mid, int high) {
		int n1 = mid - low + 1;
		int n2 = high - mid;
		System.out.println("low: " + low + " mid: " + mid + " high: " + high + ", n1:" + n1 
				+ ", n2:" + n2 + ", total size: " + (n1 + n2));
		for(int x = low; x <= high; x++) {
			System.out.println("original array, numArray[" + x + "]: " + dataArray[x]);
		}
		
		int[] L = new int[n1];
		int[] R = new int[n2];
		
		for(int i = 0; i < n1; i++) {
			L[i]= dataArray[low + i];
		}
		for(int j = 0; j < n2; j++) {
			R[j] = dataArray[mid + 1 + j]; 
		}
		
		int i = 0, j = 0;
		
		int k = low;
		
		while(i < n1 && j < n2) 
		{
			System.out.println("i: " + i + " j: " + j + " k: " + k);
			if(L[i] < R[j] ) 
			{
				dataArray[k] = L[i];
				i++;
			}
			else if(L[i]== R[j]) 
			{
				dataArray[k] = L[i];
				k++;
				i++;
				dataArray[k] = R[j];
				j++;
			}
			else if(L[i] > R[j])
			{
				dataArray[k] = R[j];
				j++;
			}
			k++;			
		}
		
		
		System.out.println("after first merge, i:" + i + " j:" + j + " k:" + k);
		while(i < n1) {			
			dataArray[k] = L[i];
			System.out.println("copy rest elements(i < n1), numArray[" + k + "]: " + dataArray[k] + ", n1:" + n1);
			k++;
			i++;
		}
		
		while(j < n2) {			
			dataArray[k] = R[j];
			System.out.println("copy rest elements(j < n2), numArray[" + k + "]: " + dataArray[k] + ", n2:" + n2);
			
			k++;
			j++;
		}
		
	}

}
