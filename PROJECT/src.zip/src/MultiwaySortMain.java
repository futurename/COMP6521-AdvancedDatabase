import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;


public class
MultiwaySortMain {
    public static void main(String[] args) throws IOException {
        Scanner in = new Scanner(System.in);
        System.out.println("Please input the relative path of the data file(\"./(folder)(/filename)\": ");
        String dataPath = in.nextLine();

        if (dataPath.equals("\\s") || !new File(dataPath).isFile()) {
            dataPath = "./TestData/data.txt";
        }

        long free1 = Runtime.getRuntime().freeMemory();
        System.out.println(free1);
        int[] testInt = new int[970000];
        for(int i = 0; i < testInt.length; i++){
            testInt[i] = i;
        }
        File dataFile = new File(dataPath);
        System.out.println(free1 - Runtime.getRuntime().freeMemory());


        FileReader fr = new FileReader(dataFile);
        BufferedReader br = new BufferedReader(fr);


        int pos = 0;
        char curCh;
        String curNumber = "";

        while ((pos = br.read()) != -1) {
            curCh = (char) pos;
            if (curCh != '\t') {
                curNumber += curCh;
                //System.out.println(curNumber);
            } else {
                curNumber = "";
                //continue;
            }
        }

    }
}
